package jogodavelha;

import java.util.ArrayList;
import javax.swing.JButton;

/**
 * @author Victória Regina Oliveira Brito Almeida
 * RA: 1850353-5
 */
public class JogoDaVelha extends javax.swing.JFrame {

    private String[][] matrizJogo = new String[3][3];
    private int contadorJogadas = 0, controleJogador = 0;
    private boolean haVencedor = false;
    private String jogadorDaVez = "";
    
    public JogoDaVelha() {
        initComponents();
    }
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btn2x0 = new javax.swing.JButton();
        btn1x0 = new javax.swing.JButton();
        btn0x1 = new javax.swing.JButton();
        btn2x1 = new javax.swing.JButton();
        btn0x2 = new javax.swing.JButton();
        btn2x2 = new javax.swing.JButton();
        btn0x0 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btn1x1 = new javax.swing.JButton();
        btn1x2 = new javax.swing.JButton();
        btnReiniciar = new javax.swing.JButton();
        lblVencedor = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btn2x0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn1x0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn0x1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn2x1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn0x2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn2x2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn0x0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        jLabel1.setText("Jogo da Velha");

        btn1x1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btn1x2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarJogada(evt);
            }
        });

        btnReiniciar.setFont(new java.awt.Font("Candara Light", 1, 14)); // NOI18N
        btnReiniciar.setText("Reiniciar");
        btnReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reiniciarJogo(evt);
            }
        });

        lblVencedor.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn0x0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn2x0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn1x0, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(170, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn1x1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn1x2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn2x1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn2x2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn0x1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn0x2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(lblVencedor, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnReiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btn0x2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn0x1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn1x1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn1x2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn0x0, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn1x0, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn2x0, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn2x1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btn2x2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblVencedor)
                .addGap(26, 26, 26)
                .addComponent(btnReiniciar)
                .addContainerGap())
        );

        lblVencedor.getAccessibleContext().setAccessibleName("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Método responsável por associar os velores dos botões às suas respectivas posições na matriz.    
    private void registrarNaMatriz(){

        matrizJogo[0][0] = btn0x0.getText();
        matrizJogo[0][1] = btn0x1.getText();
        matrizJogo[0][2] = btn0x2.getText();
        matrizJogo[1][0] = btn1x0.getText();
        matrizJogo[1][1] = btn1x1.getText();
        matrizJogo[1][2] = btn1x2.getText();
        matrizJogo[2][0] = btn2x0.getText();
        matrizJogo[2][1] = btn2x1.getText();
        matrizJogo[2][2] = btn2x2.getText();
    }
    
    /* Método responsável por informar qual caractere será registrado no botão e, após isto, controleJogador
        terá seu valor alterado para corresponder ao próximo jogador. X = 0, O = 1. */
    
    private String jogadorDaVez(){
    
        if(controleJogador == 0){
            
            jogadorDaVez = "X";
            controleJogador = 1;
            
        }else{
            jogadorDaVez = "0";
            controleJogador = 0;
        }
        
        return jogadorDaVez;
    }
    
    /* Método responsável por verificar se há um agrupamento de caracteres iguais em determinadas posições
        da matriz, informando se há um vencedor ou não.*/
    
    private boolean haVencedor(String jogadorDaVez){
    
         if(((matrizJogo[0][0] == jogadorDaVez) && (matrizJogo[0][1] == jogadorDaVez) && (matrizJogo[0][2] == jogadorDaVez))
                 || ((matrizJogo[1][0] == jogadorDaVez) && (matrizJogo[1][1] == jogadorDaVez) && (matrizJogo[1][2] == jogadorDaVez))
                 || ((matrizJogo[2][0] == jogadorDaVez)&& (matrizJogo[2][1] == jogadorDaVez) && (matrizJogo[2][2] == jogadorDaVez))
                 || ((matrizJogo[0][0] == jogadorDaVez) && (matrizJogo[1][0] == jogadorDaVez) && (matrizJogo[2][0] == jogadorDaVez))
                 || ((matrizJogo[0][1] == jogadorDaVez) && (matrizJogo[1][1] == jogadorDaVez) && (matrizJogo[2][1] == jogadorDaVez))
                 || ((matrizJogo[0][2] == jogadorDaVez) && (matrizJogo[1][2] == jogadorDaVez) && (matrizJogo[2][2] == jogadorDaVez))
                 || ((matrizJogo[0][0] == jogadorDaVez) && (matrizJogo[1][1] == jogadorDaVez) && (matrizJogo[2][2] == jogadorDaVez))
                 || ((matrizJogo[2][0] == jogadorDaVez) && (matrizJogo[1][1] == jogadorDaVez) && (matrizJogo[0][2] == jogadorDaVez))){
         
                    haVencedor = true;
         }else{
             
             haVencedor = false;
         }
         
        return haVencedor;
    }
    
    /* Método responsável por registrar as jogadas feitas, guardando na matriz os caracteres de cada jogador da vez,
        além de iniciar a verificação da existência de um vencedor a partir de cinco jogadas, pois somente é possível 
        ter a partir deste número. Havendo vencedor, este é informado. Caso contrário, o empate é avisado.
        Nas duas situações os botões são desabilitados e o contador de jogadas é zerado.*/
    
    private void registrarJogada(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarJogada
        
        contadorJogadas++;
        
        JButton botaoClicado = (JButton)evt.getSource();
       
        botaoClicado.setText(jogadorDaVez());
        
        registrarNaMatriz();
        botaoClicado.setEnabled(false); //Desabilita o botão clicado
       
        if(contadorJogadas >= 5){
        
            haVencedor = haVencedor(jogadorDaVez);
            
            if(haVencedor){

                lblVencedor.setText("O vencedor foi: " + jogadorDaVez);
                manipularBotoes(false, false);
                contadorJogadas = 0;
           
            }else if((!haVencedor) && (contadorJogadas == 9)){
                
                lblVencedor.setText("Empate!");
                manipularBotoes(false, false);
                contadorJogadas = 0;
            }
        }
    }//GEN-LAST:event_registrarJogada

    /* Método responsável por decidir estados dos botões onde serão registradas
        as jogadas, onde podem ser habilitados/desabilitados e terem seus valores
        apagados ou não.*/
    
    private void manipularBotoes(boolean habilitar, boolean resetarBotoesELabelVencedor){
        
        if(habilitar){
            btn0x0.setEnabled(true);   
            btn0x1.setEnabled(true);
            btn0x2.setEnabled(true);
            btn1x0.setEnabled(true);
            btn1x1.setEnabled(true);
            btn1x2.setEnabled(true);
            btn2x0.setEnabled(true);
            btn2x1.setEnabled(true);
            btn2x2.setEnabled(true);
            
        }else{
            btn0x0.setEnabled(false);
            btn0x1.setEnabled(false);
            btn0x2.setEnabled(false);
            btn1x0.setEnabled(false);
            btn1x1.setEnabled(false);
            btn1x2.setEnabled(false);
            btn2x0.setEnabled(false);
            btn2x1.setEnabled(false);
            btn2x2.setEnabled(false);
        }
        
        if(resetarBotoesELabelVencedor){
                btn0x0.setText("");
                btn0x1.setText("");
                btn0x2.setText("");
                btn1x0.setText("");
                btn1x1.setText("");
                btn1x2.setText("");
                btn2x0.setText("");
                btn2x1.setText("");
                btn2x2.setText("");
                
                lblVencedor.setText("");
            }
    }
    
    // Método responsável por iniciar um novo jogo após resetar os estados dos botões.
    
    private void reiniciarJogo(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reiniciarJogo
       
        this.manipularBotoes(true, true);
        this.novoJogo();
    }//GEN-LAST:event_reiniciarJogo

    // Método responsável por iniciar um novo jogo.
    
    public void novoJogo(){
        
        if(!this.isVisible()){
            this.setVisible(true);
        }
        
        contadorJogadas = 0;
        controleJogador = 0;
        new JogoDaVelha();
    }
    
    public static void main(String args[]) {

        JogoDaVelha jogoDaVelha = new JogoDaVelha();
       
        jogoDaVelha.novoJogo();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn0x0;
    private javax.swing.JButton btn0x1;
    private javax.swing.JButton btn0x2;
    private javax.swing.JButton btn1x0;
    private javax.swing.JButton btn1x1;
    private javax.swing.JButton btn1x2;
    private javax.swing.JButton btn2x0;
    private javax.swing.JButton btn2x1;
    private javax.swing.JButton btn2x2;
    private javax.swing.JButton btnReiniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblVencedor;
    // End of variables declaration//GEN-END:variables
}
