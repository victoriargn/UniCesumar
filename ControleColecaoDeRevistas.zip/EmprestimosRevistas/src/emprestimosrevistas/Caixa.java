/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.util.Scanner;

public class Caixa {

    private int numero;
    private String identificacaoEtiqueta;
    private String cor;

    public Caixa(int numero, String identificacaoEtiqueta, String cor) {
        this.numero = numero;
        this.identificacaoEtiqueta = identificacaoEtiqueta;
        this.cor = cor;
    }

    public Caixa() {
    }

    public int getNumero() {
        return numero;
    }

    public String getIdentificacaoEtiqueta() {
        return identificacaoEtiqueta;
    }

    public String getCor() {
        return cor;
    }

    public static Caixa cadastrarCaixa() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nNúmero da caixa: ");
        int numero = scanner.nextInt();

        System.out.println("Nome da etiqueta: ");
        String etiqueta = scanner.next();

        System.out.println("Cor da caixa: ");
        String cor = scanner.next();

        Caixa novaCaixa = new Caixa(numero, etiqueta, cor);

        return novaCaixa;
    }

    public static int buscarPorUmaCaixa(Caixa[] minhasCaixas, int numeroDaCaixa) {
        int posicaoNoVetor = -1;

        for (int x = 0; x < minhasCaixas.length; x++) {
            if (minhasCaixas[x] == null) {
                break;
            } else if (minhasCaixas[x].getNumero() == numeroDaCaixa) {
                posicaoNoVetor = x;
                break;
            }
        }
        return posicaoNoVetor;
    }
}
