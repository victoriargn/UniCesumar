/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.util.Scanner;

public class Amigo {

    private String nome;
    private String telefone;
    private String localAmigo;

    public Amigo(String nome, String telefone, String localAmigo) {
        this.nome = nome;
        this.telefone = telefone;
        this.localAmigo = localAmigo;
    }

    public Amigo() {
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getLocalAmigo() {
        return localAmigo;
    }

    public static Amigo cadastrarAmigo() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nNome: ");
        String nome = scanner.nextLine();

        System.out.println("Telefone: ");
        String telefone = scanner.nextLine();

        System.out.println("De onde é? ");
        String local = scanner.nextLine();

        Amigo novoAmigo = new Amigo(nome, telefone, local);

        return novoAmigo;
    }

    public static int buscarPorUmAmigo(Amigo[] amigos, String nomeDoAmigo) {
        int posicaoNoVetor = -1;

        for (int x = 0; x < amigos.length; x++) {
            if (amigos[x] == null) {
                break;
            } else if (amigos[x].getNome().equals(nomeDoAmigo)) {
                posicaoNoVetor = x;
                break;
            }
        }
        return posicaoNoVetor;
    }
}
