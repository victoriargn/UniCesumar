/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.util.Scanner;

public class Colecao {

    private String nome;

    public Colecao(String nome) {
        this.nome = nome;
    }

    public Colecao() {
    }

    public String getNome() {
        return nome;
    }

    public static Colecao cadastrarColecao() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nNome da coleção: ");
        String nome = scanner.nextLine();

        Colecao novaColecao = new Colecao(nome);

        return novaColecao;
    }

    public static int buscarPorUmaColecao(Colecao[] minhasColecoes, String nomeDaColecao) {
        int posicaoNoVetor = -1;

        for (int x = 0; x < minhasColecoes.length; x++) {
            if (minhasColecoes[x] == null) {
                break;
            } else if (minhasColecoes[x].getNome().equals(nomeDaColecao)) {
                posicaoNoVetor = x;
                break;
            }
        }
        return posicaoNoVetor;

    }
}
