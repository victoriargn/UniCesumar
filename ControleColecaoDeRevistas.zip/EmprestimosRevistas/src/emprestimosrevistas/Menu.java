/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.text.ParseException;
import java.util.Scanner;
import java.text.SimpleDateFormat;

public class Menu {

    int contCadAmigo = 0, contCadCaixa = 0, contCadColecao = 0, contCadRevista = 0, contCadEmprestimo = 0;

    Amigo[] meusAmigos = new Amigo[3];
    Caixa[] minhasCaixas = new Caixa[3];
    Colecao[] minhasColecoes = new Colecao[3];
    Revista[] minhasRevistas = new Revista[3];
    Emprestimo[] meusEmprestimos = new Emprestimo[3];

    Scanner scanner = new Scanner(System.in);

    public void executarMenu() throws ParseException {

        int operacao;

        do {
            System.out.println("\nO que deseja fazer?");

            System.out.println("1. Cadastrar um amigo.");
            System.out.println("2. Cadastrar uma caixa.");
            System.out.println("3. Cadastrar uma coleção.");
            System.out.println("4. Cadastrar uma revista.");
            System.out.println("5. Registrar um empréstimo.");
            System.out.println("6. Mostrar todos os itens cadastrados.");
            System.out.println("7. Sair.\n");

            operacao = scanner.nextInt();

            this.realizarOperacaoEscolhida(operacao);

        } while (operacao != 7);

    }

    private void realizarOperacaoEscolhida(int operacao) throws ParseException {

        switch (operacao) {
            case 1:

                if (!this.verificarLimiteDeCadastro(contCadAmigo)) {
                    this.meusAmigos[contCadAmigo] = Amigo.cadastrarAmigo();
                    contCadAmigo++;
                } else {
                    System.out.println("Limite de amigos atingido.\n");
                }

                break;

            case 2:

                if (!this.verificarLimiteDeCadastro(contCadCaixa)) {
                    this.minhasCaixas[contCadCaixa] = Caixa.cadastrarCaixa();
                    contCadCaixa++;
                } else {
                    System.out.println("Limite de caixas atingido.\n");
                }

                break;

            case 3:
                if (!this.verificarLimiteDeCadastro(contCadColecao)) {
                    this.minhasColecoes[contCadColecao] = Colecao.cadastrarColecao();
                    contCadColecao++;
                } else {
                    System.out.println("Limite de coleções atingido.\n");
                }

                break;

            case 4:
                if (!this.verificarLimiteDeCadastro(contCadRevista)) {

                    if ((contCadCaixa > 0) && (contCadColecao > 0)) {

                        System.out.println("Qual o número da caixa em que a revista ficará?");
                        int numeroDaCaixa = scanner.nextInt();

                        int posicaoCaixaEncontrada = Caixa.buscarPorUmaCaixa(minhasCaixas, numeroDaCaixa);

                        System.out.println("Qual o nome da coleção a qual a revista pertencerá?");
                        String nomeDaColecao = scanner.next();

                        int posicaoColecaoEncontrada = Colecao.buscarPorUmaColecao(minhasColecoes, nomeDaColecao);

                        if (posicaoCaixaEncontrada != -1) {

                            if (posicaoColecaoEncontrada != -1) {
                                this.minhasRevistas[contCadRevista] = Revista.novaRevista(minhasCaixas,
                                        posicaoCaixaEncontrada, minhasColecoes, posicaoColecaoEncontrada);

                                contCadRevista++;
                            } else {
                                System.out.println("Coleção não encontrada.\n");
                            }
                        } else {
                            System.out.println("Caixa não encontrada.\n");
                        }
                    } else {
                        System.out.println("Para cadastrar uma revista são necessárias caixas e coleções cadastradas. \n");
                    }
                } else {
                    System.out.println("Limite de revistas atingido. \n");
                }
                break;

            case 5:

                if (!verificarLimiteDeCadastro(contCadEmprestimo)) {

                    System.out.println("A revista será emprestada para qual amigo?");
                    String nomeDoAmigo = scanner.next();

                    int posicaoAmigoEncontrado = Amigo.buscarPorUmAmigo(meusAmigos, nomeDoAmigo);

                    if (posicaoAmigoEncontrado != -1) {
                        boolean houveEmprestimo = Emprestimo.verificarSeJaHouveEmprestimo(meusEmprestimos, nomeDoAmigo);

                        if (houveEmprestimo) {
                            System.out.println("O seu amigo já tem uma revista emprestada. Aguarde até a data de devolução para"
                                    + "um novo empréstimo.");
                        } else {
                            System.out.println("Qual o número de ordem da revista na lista de itens cadastrados? Se necessário,"
                                    + "consulte-a na opção 6 do menu.");

                            int posicaoDaRevistaNoVetor = scanner.nextInt();
                            int posicaoRevistaEncontrada = Revista.buscarUmaRevista(minhasRevistas, posicaoDaRevistaNoVetor);

                            if (posicaoRevistaEncontrada != -1) {
                                meusEmprestimos[contCadEmprestimo] = Emprestimo.novoEmprestimo(meusAmigos, posicaoAmigoEncontrado,
                                        minhasRevistas, posicaoRevistaEncontrada, meusEmprestimos, contCadEmprestimo);

                                contCadEmprestimo++;
                            } else {
                                System.out.println("Revista não encontrada. Cadastre-a ou escolha outra.\n");
                            }
                        }

                    } else {
                        System.out.println("Amigo não encontrado. Cadastre-o.\n");
                    }
                } else {
                    System.out.println("Limite de empréstimos atingido.\n");
                }

                break;

            case 6:
                this.exibirItensCadastrados();
        }
    }

    private boolean verificarLimiteDeCadastro(int controleDeCadastro) {
        boolean limiteAtingido = false;

        if (controleDeCadastro == 3) {
            return true;
        }
        return limiteAtingido;
    }

    private void exibirItensCadastrados() {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("*------ Amigos ------*");

        if (contCadAmigo == 0) {
            System.out.println("Não há amigos cadastrados.\n");

        } else {
            for (int x = 0; x < contCadAmigo; x++) {
                System.out.println(x + ". Nome: " + meusAmigos[x].getNome() + ", Telefone: " + meusAmigos[x].getTelefone()
                        + ", Local: " + meusAmigos[x].getLocalAmigo());
            }
        }

        System.out.println("\n*------ Caixas ------*");
        if (contCadCaixa == 0) {
            System.out.println("Não há caixas cadastradas.\n");

        } else {
            for (int x = 0; x < contCadCaixa; x++) {
                System.out.println((x + 1) + ". Número: " + minhasCaixas[x].getNumero() + ", Etiqueta: "
                        + minhasCaixas[x].getIdentificacaoEtiqueta() + ", Cor: " + minhasCaixas[x].getCor());
            }
        }

        System.out.println("\n*------ Coleções ------*");
        if (contCadColecao == 0) {
            System.out.println("Não há coleções cadastradas.\n");

        } else {
            for (int x = 0; x < contCadColecao; x++) {
                System.out.println((x + 1) + ". Nome:" + minhasColecoes[x].getNome());
            }
        }

        System.out.println("\n*------ Revistas ------*");
        if (contCadRevista == 0) {
            System.out.println("Não há revistas cadastradas.\n");

        } else {
            for (int x = 0; x < contCadRevista; x++) {
                System.out.println((x + 1) + ". Caixa " + minhasRevistas[x].getCaixa().getNumero() + ", Coleção: "
                        + minhasRevistas[x].getColecao().getNome() + ", Nº Edição: " + minhasRevistas[x].getNumeroEdicao()
                        + ", Ano Edição: " + minhasRevistas[x].getAnoEdicao());
            }
        }

        System.out.println("\n*------ Empréstimos ------*");
        if (contCadEmprestimo == 0) {
            System.out.println("Não há empréstimos cadastrados.\n");

        } else {
            for (int x = 0; x < contCadEmprestimo; x++) {
                System.out.println((x + 1) + ". Para o amigo " + meusEmprestimos[x].getAmigo().getNome()
                        + ", Revista da caixa de etiqueta: " + meusEmprestimos[x].getRevista().getCaixa().getIdentificacaoEtiqueta()
                        + ", Nº Edição: " + meusEmprestimos[x].getRevista().getNumeroEdicao()
                        + ", Data do empréstimo: " + sdf.format(meusEmprestimos[x].getDataEmprestimo())
                        + ", Data de devolução: " + sdf.format(meusEmprestimos[x].getDataDevolucao()));
            }
        }
    }
}
