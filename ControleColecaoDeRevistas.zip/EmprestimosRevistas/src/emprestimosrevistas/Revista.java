/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.util.Scanner;

public class Revista {

    private Colecao colecao = new Colecao();
    private int numeroEdicao;
    private int anoEdicao;
    private Caixa caixa = new Caixa();
    
    public Revista() {
    }

    public void setColecao(Colecao colecao) {
        this.colecao = colecao;
    }

    public Colecao getColecao() {
        return colecao;
    }

    public void setNumeroEdicao(int numeroEdicao) {
        this.numeroEdicao = numeroEdicao;
    }

    public void setAnoEdicao(int ano) {
        this.anoEdicao = ano;
    }

    public void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }

    public int getNumeroEdicao() {
        return numeroEdicao;
    }

    public int getAnoEdicao() {
        return anoEdicao;
    }

    public Caixa getCaixa() {
        return caixa;
    }

    public static int buscarUmaRevista(Revista[] revistas, int posicaoDaRevistaNoVetor) {
        int posicaoNoVetor = -1;

        if (posicaoDaRevistaNoVetor <= revistas.length) {
            if (revistas[posicaoDaRevistaNoVetor - 1] != null) {
                posicaoNoVetor = posicaoDaRevistaNoVetor-1;
            }
        }
        return posicaoNoVetor;
    }

    public static Revista novaRevista(Caixa[] minhasCaixas, int posicaoCaixaEncontrada, Colecao[] minhasColecoes,
            int posicaoColecaoEncontrada) {

        Scanner scanner = new Scanner(System.in);

        Revista novaRevista = new Revista();
        novaRevista.setCaixa(minhasCaixas[posicaoCaixaEncontrada]);
        novaRevista.setColecao(minhasColecoes[posicaoColecaoEncontrada]);
                
        System.out.println("Número da edição:");
        int numeroEdicao = scanner.nextInt();
        novaRevista.setNumeroEdicao(numeroEdicao);

        System.out.println("Ano da edição:");
        int anoEdicao = scanner.nextInt();
        novaRevista.setAnoEdicao(anoEdicao);

        return novaRevista;
    }
}
