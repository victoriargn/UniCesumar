/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */
package emprestimosrevistas;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Emprestimo {

    private final Date dataEmprestimo;
    private final Date dataDevolucao;
    private final Amigo amigo;
    private final Revista revista;

    public Emprestimo(Date dataEmprestimo, Date dataDevolucao, Amigo amigo, Revista revista) {

        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.amigo = amigo;
        this.revista = revista;
    }

    public Amigo getAmigo() {
        return amigo;
    }

    public Revista getRevista() {
        return revista;
    }

    public Date getDataEmprestimo() {
        return dataEmprestimo;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }

    public static boolean verificarSeJaHouveEmprestimo(Emprestimo[] emprestimos, String nomeDoAmigo) {
        boolean houveEmprestimo = false;

        for (Emprestimo emprestimo : emprestimos) {
            if (emprestimo == null) {
                break;
            } else if (emprestimo.amigo.getNome().equals(nomeDoAmigo)) {
                houveEmprestimo = true;
                break;
            }
        }
        return houveEmprestimo;
    }

    public static Emprestimo novoEmprestimo(Amigo[] meusAmigos, int posicaoAmigoEncontrado, Revista[] minhasRevistas,
            int posicaoRevistaEncontrada, Emprestimo[] meusEmprestimos, int contCadEmprestimo) throws ParseException {

        Scanner scanner = new Scanner(System.in);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        System.out.println("Data do Empréstimo: ");
        String dataEmprestimo = scanner.next();

        System.out.println("Data da Devolução: ");
        String dataDevolucao = scanner.next();

        Emprestimo novoEmprestimo = new Emprestimo(sdf.parse(dataEmprestimo), sdf.parse(dataDevolucao),
                meusAmigos[posicaoAmigoEncontrado], minhasRevistas[posicaoRevistaEncontrada]);

        return novoEmprestimo;
    }
}
