/*
 * @author Victoria Regina Oliveira Brito Almeida
 * RA: 1850383-5
 */

package emprestimosrevistas;

import java.text.ParseException;

public class ControleColecaoRevistas {

    public static void main(String[] args ) throws ParseException{
        
       Menu menu = new Menu();
       menu.executarMenu();
    }
}
